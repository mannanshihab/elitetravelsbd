<?php

namespace App\Livewire\Partials;

use Livewire\Component;

class LayoutNavbar extends Component
{
    public function render()
    {
        return view('livewire.partials.layout-navbar');
    }
}
