<?php

namespace App\Livewire\Partials;

use Livewire\Component;

class LayoutMenu extends Component
{
    public function render()
    {
        return view('livewire.partials.layout-menu');
    }
}
